--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3 (Debian 13.3-1.pgdg100+1)
-- Dumped by pg_dump version 13.2 (Debian 13.2-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    last_login timestamp without time zone
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: accounts_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_user_id_seq OWNER TO postgres;

--
-- Name: accounts_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_user_id_seq OWNED BY public.accounts.user_id;


--
-- Name: completed_items; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.completed_items (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    start_at timestamp(0) without time zone NOT NULL,
    end_at timestamp(0) without time zone NOT NULL,
    sport_id bigint NOT NULL,
    planned_item_id bigint NOT NULL,
    student_id bigint NOT NULL
);


ALTER TABLE public.completed_items OWNER TO hkuit;

--
-- Name: completed_items_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.completed_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.completed_items_id_seq OWNER TO hkuit;

--
-- Name: completed_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.completed_items_id_seq OWNED BY public.completed_items.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO hkuit;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO hkuit;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO hkuit;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO hkuit;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_resets OWNER TO hkuit;

--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO hkuit;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO hkuit;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: planned_items; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.planned_items (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    planned_date timestamp(0) without time zone NOT NULL,
    times integer NOT NULL,
    sport_id bigint NOT NULL,
    plan_id bigint NOT NULL
);


ALTER TABLE public.planned_items OWNER TO hkuit;

--
-- Name: planned_items_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.planned_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planned_items_id_seq OWNER TO hkuit;

--
-- Name: planned_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.planned_items_id_seq OWNED BY public.planned_items.id;


--
-- Name: plans; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.plans (
    id bigint NOT NULL,
    end_at timestamp(0) without time zone NOT NULL,
    start_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    std_class_id bigint NOT NULL
);


ALTER TABLE public.plans OWNER TO hkuit;

--
-- Name: plans_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plans_id_seq OWNER TO hkuit;

--
-- Name: plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.plans_id_seq OWNED BY public.plans.id;


--
-- Name: sports; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.sports (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.sports OWNER TO hkuit;

--
-- Name: sports_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.sports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sports_id_seq OWNER TO hkuit;

--
-- Name: sports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.sports_id_seq OWNED BY public.sports.id;


--
-- Name: statistics; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.statistics (
    id bigint NOT NULL,
    label character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    completed_item_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.statistics OWNER TO hkuit;

--
-- Name: statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.statistics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.statistics_id_seq OWNER TO hkuit;

--
-- Name: statistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.statistics_id_seq OWNED BY public.statistics.id;


--
-- Name: std_class_teacher; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.std_class_teacher (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    teacher_id bigint NOT NULL,
    std_class_id bigint NOT NULL
);


ALTER TABLE public.std_class_teacher OWNER TO hkuit;

--
-- Name: std_class_teacher_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.std_class_teacher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.std_class_teacher_id_seq OWNER TO hkuit;

--
-- Name: std_class_teacher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.std_class_teacher_id_seq OWNED BY public.std_class_teacher.id;


--
-- Name: std_classes; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.std_classes (
    id bigint NOT NULL,
    year character varying(255) NOT NULL,
    class character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.std_classes OWNER TO hkuit;

--
-- Name: std_classes_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.std_classes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.std_classes_id_seq OWNER TO hkuit;

--
-- Name: std_classes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.std_classes_id_seq OWNED BY public.std_classes.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.students (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    name character varying(255) NOT NULL,
    std_num character varying(255) NOT NULL,
    class_num character varying(255) NOT NULL,
    std_class_id bigint NOT NULL
);


ALTER TABLE public.students OWNER TO hkuit;

--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.students_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.students_id_seq OWNER TO hkuit;

--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: teachers; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.teachers (
    id bigint NOT NULL,
    stuff_id character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.teachers OWNER TO hkuit;

--
-- Name: teachers_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.teachers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teachers_id_seq OWNER TO hkuit;

--
-- Name: teachers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.teachers_id_seq OWNED BY public.teachers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255),
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    password_init_raw character varying(255) NOT NULL,
    last_login timestamp(0) without time zone,
    userable_type character varying(255) NOT NULL,
    userable_id bigint NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO hkuit;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO hkuit;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: web_managers; Type: TABLE; Schema: public; Owner: hkuit
--

CREATE TABLE public.web_managers (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.web_managers OWNER TO hkuit;

--
-- Name: web_managers_id_seq; Type: SEQUENCE; Schema: public; Owner: hkuit
--

CREATE SEQUENCE public.web_managers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.web_managers_id_seq OWNER TO hkuit;

--
-- Name: web_managers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hkuit
--

ALTER SEQUENCE public.web_managers_id_seq OWNED BY public.web_managers.id;


--
-- Name: accounts user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts ALTER COLUMN user_id SET DEFAULT nextval('public.accounts_user_id_seq'::regclass);


--
-- Name: completed_items id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.completed_items ALTER COLUMN id SET DEFAULT nextval('public.completed_items_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: planned_items id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.planned_items ALTER COLUMN id SET DEFAULT nextval('public.planned_items_id_seq'::regclass);


--
-- Name: plans id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.plans ALTER COLUMN id SET DEFAULT nextval('public.plans_id_seq'::regclass);


--
-- Name: sports id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.sports ALTER COLUMN id SET DEFAULT nextval('public.sports_id_seq'::regclass);


--
-- Name: statistics id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.statistics ALTER COLUMN id SET DEFAULT nextval('public.statistics_id_seq'::regclass);


--
-- Name: std_class_teacher id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.std_class_teacher ALTER COLUMN id SET DEFAULT nextval('public.std_class_teacher_id_seq'::regclass);


--
-- Name: std_classes id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.std_classes ALTER COLUMN id SET DEFAULT nextval('public.std_classes_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: teachers id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.teachers ALTER COLUMN id SET DEFAULT nextval('public.teachers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: web_managers id; Type: DEFAULT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.web_managers ALTER COLUMN id SET DEFAULT nextval('public.web_managers_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (user_id, username, password, email, created_on, last_login) FROM stdin;
\.


--
-- Data for Name: completed_items; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.completed_items (id, created_at, updated_at, start_at, end_at, sport_id, planned_item_id, student_id) FROM stdin;
1	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-03-31 00:00:00	2021-04-01 00:00:00	1	1	1
2	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-03-31 00:00:00	2021-04-01 00:00:00	2	2	1
3	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-03-31 00:00:00	2021-04-01 00:00:00	3	3	1
4	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-07 00:00:00	2021-04-08 00:00:00	1	4	1
5	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-07 00:00:00	2021-04-08 00:00:00	2	5	1
6	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-07 00:00:00	2021-04-08 00:00:00	3	6	1
7	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-14 00:00:00	2021-04-15 00:00:00	1	7	1
8	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-14 00:00:00	2021-04-15 00:00:00	2	8	1
9	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-14 00:00:00	2021-04-15 00:00:00	3	9	1
10	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-21 00:00:00	2021-04-22 00:00:00	1	10	1
11	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-21 00:00:00	2021-04-22 00:00:00	2	11	1
12	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-21 00:00:00	2021-04-22 00:00:00	3	12	1
13	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-28 00:00:00	2021-04-29 00:00:00	1	13	1
14	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-28 00:00:00	2021-04-29 00:00:00	2	14	1
15	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-28 00:00:00	2021-04-29 00:00:00	3	15	1
16	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-05 00:00:00	2021-05-06 00:00:00	1	16	1
17	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-05 00:00:00	2021-05-06 00:00:00	2	17	1
18	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-05 00:00:00	2021-05-06 00:00:00	3	18	1
19	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-12 00:00:00	2021-05-13 00:00:00	1	19	1
20	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-12 00:00:00	2021-05-13 00:00:00	2	20	1
21	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-12 00:00:00	2021-05-13 00:00:00	3	21	1
22	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-19 00:00:00	2021-05-20 00:00:00	1	22	1
23	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-19 00:00:00	2021-05-20 00:00:00	2	23	1
24	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-19 00:00:00	2021-05-20 00:00:00	3	24	1
25	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-05-26 00:00:00	2021-05-27 00:00:00	1	25	1
26	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-05-26 00:00:00	2021-05-27 00:00:00	2	26	1
27	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-05-26 00:00:00	2021-05-27 00:00:00	3	27	1
28	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-06-02 00:00:00	2021-06-03 00:00:00	1	28	1
29	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-06-02 00:00:00	2021-06-03 00:00:00	2	29	1
30	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-06-02 00:00:00	2021-06-03 00:00:00	3	30	1
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_resets_table	1
3	2019_08_19_000000_create_failed_jobs_table	1
4	2019_12_14_000001_create_personal_access_tokens_table	1
5	2020_11_16_074600_create_plans_table	1
6	2020_11_16_074722_create_statistics_table	1
7	2020_11_16_075152_create_sports_table	1
8	2020_11_16_075542_create_planned_items_table	1
9	2020_11_16_080211_create_completed_items_table	1
10	2020_11_16_090050_create_std_classes_table	1
11	2020_11_17_024806_create_students_table	1
12	2020_11_17_024935_create_web_managers_table	1
13	2020_11_17_025003_create_teachers_table	1
14	2021_03_01_045409_add_index_to_students_table	1
15	2021_03_24_073406_create_pivot_teacher_stdclass_table	1
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.password_resets (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: planned_items; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.planned_items (id, created_at, updated_at, planned_date, times, sport_id, plan_id) FROM stdin;
1	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-03-29 00:00:00	30	1	1
2	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-03-29 00:00:00	20	2	1
3	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-03-29 00:00:00	25	3	1
4	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-05 00:00:00	30	1	2
5	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-05 00:00:00	20	2	2
6	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-05 00:00:00	25	3	2
7	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-12 00:00:00	10	1	3
8	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-12 00:00:00	30	2	3
9	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-12 00:00:00	20	3	3
10	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-19 00:00:00	10	1	4
11	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-19 00:00:00	30	2	4
12	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-19 00:00:00	20	3	4
13	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-26 00:00:00	20	1	5
14	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-26 00:00:00	10	2	5
15	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-04-26 00:00:00	15	3	5
16	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-03 00:00:00	20	1	6
17	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-03 00:00:00	10	2	6
18	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-03 00:00:00	15	3	6
19	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-10 00:00:00	25	1	7
20	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-10 00:00:00	25	2	7
21	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-10 00:00:00	30	3	7
22	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-17 00:00:00	25	1	8
23	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-17 00:00:00	25	2	8
24	2021-06-10 08:56:14	2021-06-10 08:56:14	2021-05-17 00:00:00	30	3	8
25	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-05-24 00:00:00	10	1	9
26	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-05-24 00:00:00	20	2	9
27	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-05-24 00:00:00	20	3	9
28	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-05-31 00:00:00	10	1	10
29	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-05-31 00:00:00	20	2	10
30	2021-06-10 08:56:15	2021-06-10 08:56:15	2021-05-31 00:00:00	20	3	10
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.plans (id, end_at, start_at, created_at, updated_at, std_class_id) FROM stdin;
1	2021-04-04 23:59:59	2021-03-29 00:00:00	2021-06-10 08:56:14	2021-06-10 08:56:14	1
2	2021-04-11 23:59:59	2021-04-05 00:00:00	2021-06-10 08:56:14	2021-06-10 08:56:14	1
3	2021-04-18 23:59:59	2021-04-12 00:00:00	2021-06-10 08:56:14	2021-06-10 08:56:14	1
4	2021-04-25 23:59:59	2021-04-19 00:00:00	2021-06-10 08:56:14	2021-06-10 08:56:14	1
5	2021-05-02 23:59:59	2021-04-26 00:00:00	2021-06-10 08:56:14	2021-06-10 08:56:14	1
6	2021-05-09 23:59:59	2021-05-03 00:00:00	2021-06-10 08:56:14	2021-06-10 08:56:14	1
7	2021-05-16 23:59:59	2021-05-10 00:00:00	2021-06-10 08:56:14	2021-06-10 08:56:14	1
8	2021-05-23 23:59:59	2021-05-17 00:00:00	2021-06-10 08:56:14	2021-06-10 08:56:14	1
9	2021-05-30 23:59:59	2021-05-24 00:00:00	2021-06-10 08:56:15	2021-06-10 08:56:15	1
10	2021-06-06 23:59:59	2021-05-31 00:00:00	2021-06-10 08:56:15	2021-06-10 08:56:15	1
\.


--
-- Data for Name: sports; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.sports (id, name, description, created_at, updated_at) FROM stdin;
1	Sit-up		2021-06-10 08:56:12	2021-06-10 08:56:12
2	Push-up		\N	\N
3	Squat		\N	\N
4	Jump		\N	\N
\.


--
-- Data for Name: statistics; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.statistics (id, label, value, completed_item_id, created_at, updated_at) FROM stdin;
1	count	50	1	2021-06-10 08:56:14	2021-06-10 08:56:14
2	count	20	2	2021-06-10 08:56:14	2021-06-10 08:56:14
3	count	30	3	2021-06-10 08:56:14	2021-06-10 08:56:14
4	count	50	4	2021-06-10 08:56:14	2021-06-10 08:56:14
5	count	20	5	2021-06-10 08:56:14	2021-06-10 08:56:14
6	count	30	6	2021-06-10 08:56:14	2021-06-10 08:56:14
7	count	10	7	2021-06-10 08:56:14	2021-06-10 08:56:14
8	count	40	8	2021-06-10 08:56:14	2021-06-10 08:56:14
9	count	25	9	2021-06-10 08:56:14	2021-06-10 08:56:14
10	count	10	10	2021-06-10 08:56:14	2021-06-10 08:56:14
11	count	40	11	2021-06-10 08:56:14	2021-06-10 08:56:14
12	count	25	12	2021-06-10 08:56:14	2021-06-10 08:56:14
13	count	30	13	2021-06-10 08:56:14	2021-06-10 08:56:14
14	count	20	14	2021-06-10 08:56:14	2021-06-10 08:56:14
15	count	20	15	2021-06-10 08:56:14	2021-06-10 08:56:14
16	count	30	16	2021-06-10 08:56:14	2021-06-10 08:56:14
17	count	20	17	2021-06-10 08:56:14	2021-06-10 08:56:14
18	count	20	18	2021-06-10 08:56:14	2021-06-10 08:56:14
19	count	40	19	2021-06-10 08:56:14	2021-06-10 08:56:14
20	count	20	20	2021-06-10 08:56:14	2021-06-10 08:56:14
21	count	50	21	2021-06-10 08:56:14	2021-06-10 08:56:14
22	count	40	22	2021-06-10 08:56:14	2021-06-10 08:56:14
23	count	20	23	2021-06-10 08:56:14	2021-06-10 08:56:14
24	count	50	24	2021-06-10 08:56:15	2021-06-10 08:56:15
25	count	20	25	2021-06-10 08:56:15	2021-06-10 08:56:15
26	count	30	26	2021-06-10 08:56:15	2021-06-10 08:56:15
27	count	25	27	2021-06-10 08:56:15	2021-06-10 08:56:15
28	count	20	28	2021-06-10 08:56:15	2021-06-10 08:56:15
29	count	30	29	2021-06-10 08:56:15	2021-06-10 08:56:15
30	count	25	30	2021-06-10 08:56:15	2021-06-10 08:56:15
\.


--
-- Data for Name: std_class_teacher; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.std_class_teacher (id, created_at, updated_at, teacher_id, std_class_id) FROM stdin;
1	\N	\N	1	1
2	\N	\N	1	2
3	\N	\N	1	3
4	\N	\N	1	4
5	\N	\N	2	5
6	\N	\N	2	6
7	\N	\N	2	7
8	\N	\N	2	8
\.


--
-- Data for Name: std_classes; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.std_classes (id, year, class, created_at, updated_at) FROM stdin;
1	1	A	2021-06-10 08:56:13	2021-06-10 08:56:13
2	1	B	2021-06-10 08:56:13	2021-06-10 08:56:13
3	2	A	2021-06-10 08:56:13	2021-06-10 08:56:13
4	2	B	2021-06-10 08:56:13	2021-06-10 08:56:13
5	1	C	2021-06-10 08:56:13	2021-06-10 08:56:13
6	1	D	2021-06-10 08:56:13	2021-06-10 08:56:13
7	2	C	2021-06-10 08:56:13	2021-06-10 08:56:13
8	2	D	2021-06-10 08:56:13	2021-06-10 08:56:13
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.students (id, created_at, updated_at, name, std_num, class_num, std_class_id) FROM stdin;
1	2021-06-10 08:56:13	2021-06-10 08:56:13	Peter Cheung	A000001	1	1
2	2021-06-10 08:56:13	2021-06-10 08:56:13	Marry Wong	A000002	2	1
3	2021-06-10 08:56:13	2021-06-10 08:56:13	Liam Chan	A000003	1	2
4	2021-06-10 08:56:13	2021-06-10 08:56:13	Noah Wong	A000004	2	2
5	2021-06-10 08:56:13	2021-06-10 08:56:13	Easton Chan	A000011	1	3
6	2021-06-10 08:56:13	2021-06-10 08:56:13	Asher Wong	A000012	2	3
7	2021-06-10 08:56:13	2021-06-10 08:56:13	Jeremiah Chan	A000013	1	4
8	2021-06-10 08:56:13	2021-06-10 08:56:13	Adrian Wong	A000014	2	4
9	2021-06-10 08:56:13	2021-06-10 08:56:13	Oliver	A000005	1	5
10	2021-06-10 08:56:13	2021-06-10 08:56:13	Connor	A000006	2	5
11	2021-06-10 08:56:14	2021-06-10 08:56:14	William	A000007	1	6
12	2021-06-10 08:56:14	2021-06-10 08:56:14	Isabella	A00008	2	6
13	2021-06-10 08:56:14	2021-06-10 08:56:14	Sarah	A00009	1	7
14	2021-06-10 08:56:14	2021-06-10 08:56:14	Walsh	A000015	2	7
15	2021-06-10 08:56:14	2021-06-10 08:56:14	Roberts	A000016	1	8
16	2021-06-10 08:56:14	2021-06-10 08:56:14	Jones	A000017	2	8
\.


--
-- Data for Name: teachers; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.teachers (id, stuff_id, created_at, updated_at) FROM stdin;
1	AA0001	2021-06-10 08:56:13	2021-06-10 08:56:13
2	AA0002	2021-06-10 08:56:13	2021-06-10 08:56:13
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.users (id, username, email, email_verified_at, password, password_init_raw, last_login, userable_type, userable_id, remember_token, created_at, updated_at) FROM stdin;
1	ken123	ken@123.com	\N	$2y$10$Y9ootVr9Rbhl4B0OuCUzH.mSWmkk3w9BdcTwuNfJpCFdN1mlN.gyC	123	\N	App\\Models\\Teacher	1	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
2	zxy123	zxy@123.com	\N	$2y$10$WEQsqxpG6c8qYD.qr6Z8iuCg52IQn9MYJfW1OXSQf6EZhX5OjfnV.	123	\N	App\\Models\\Teacher	2	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
3	marry123	marry@123.com	\N	$2y$10$dyPg9QPetV9mGyuZgtSYiOj4VuPiMRJ2CnV7PBszMe5Mo2EaUH.QW	123	\N	App\\Models\\WebManager	1	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
4	peterchan123	peterchan@123.com	\N	$2y$10$XLD3Knp2emI.Y/2XKF.2J.irTWFN40YMSmBYz1K4YKJv6JgsWkNNu	123	\N	App\\Models\\Student	1	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
5	marrywrong	marrywrong@123.com	\N	$2y$10$7Et0YG59XwEh.NhjZhf/nuc6xpEkD9LgEyGkCmVE0UwLtbSPpbAcu	123	\N	App\\Models\\Student	2	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
6	liamchan	liamchan@123.com	\N	$2y$10$1N0pyfEofClZ2NTms7GAHOThTYMtjk50M0SCTc771w/MFSIE6QusC	123	\N	App\\Models\\Student	3	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
7	noahwong	noahwong@123.com	\N	$2y$10$a8vDKEgoe4xessme2v4c5.qiz0WEO816OkYMPsRBFbRJ4oDDxoNJO	123	\N	App\\Models\\Student	4	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
8	eastonchan	eastonchan@123.com	\N	$2y$10$euCqWAunravMGaAi2i2jeur625RWYnCvV1XFDdB2wnF5M9v7zQl5W	123	\N	App\\Models\\Student	5	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
9	asherwong	asherwong@123.com	\N	$2y$10$HLoHzcQwdLM3x5YBQNnV1uuiDZJZw0lDq2LBwCMnLzAb3L259a/Ca	123	\N	App\\Models\\Student	6	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
10	jeremiahchan	jeremiahchan@123.com	\N	$2y$10$YpZKr1kzMoyCmmw60wPpbOKjV4Z6pTKwik1.n9iz.Edudp8X2366W	123	\N	App\\Models\\Student	7	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
11	adrianwong	adrianwong@123.com	\N	$2y$10$McGF0.FRnStudlQ.xiR2Zuo7gbz.yW.JrCr5Hv9azNCN6VLhIVYBi	123	\N	App\\Models\\Student	8	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
12	oliver	oliver@123.com	\N	$2y$10$9Gdz8VLpBXqI1uLTWjiaXumBYn6kqlAnueZZdlbY9MlquSYId.Mt6	123	\N	App\\Models\\Student	9	\N	2021-06-10 08:56:13	2021-06-10 08:56:13
13	connor	connor@123.com	\N	$2y$10$2lWvDt7Sl8jbzRw0eBvO/.UrrnvpLsg1SSl1xfplEonqp69tgbijm	123	\N	App\\Models\\Student	10	\N	2021-06-10 08:56:14	2021-06-10 08:56:14
14	william	william@123.com	\N	$2y$10$TU3mC/Ub2lU94XbT/Es.TOmrLbCzrBcKV2TJtmZc7cXSmhD6bJ0lK	123	\N	App\\Models\\Student	11	\N	2021-06-10 08:56:14	2021-06-10 08:56:14
15	isabella	isabella@123.com	\N	$2y$10$pVPpSZ2F43BVf8u5Hxz7wOgzvQTL5wtJlGDv.Qqo.BbMZqDmzgv4G	123	\N	App\\Models\\Student	12	\N	2021-06-10 08:56:14	2021-06-10 08:56:14
16	sarah	sarah@123.com	\N	$2y$10$MVzbOWR4/nuhK/STeg4Y6eVsivPiqJ8XH2s8xByYBJvMVmih1y4Ii	123	\N	App\\Models\\Student	13	\N	2021-06-10 08:56:14	2021-06-10 08:56:14
17	walsh	walsh@123.com	\N	$2y$10$VwB23hlLm86nR2k7ymxT0.m/Vtv6v1bkGlmmq6Tq1h69no9jiccja	123	\N	App\\Models\\Student	14	\N	2021-06-10 08:56:14	2021-06-10 08:56:14
18	roberts	roberts@123.com	\N	$2y$10$GxUwhz8yh/pU2LJBTkEJZuVXvyfrrIz8/tPgRkn5u60EHGQq0t4/a	123	\N	App\\Models\\Student	15	\N	2021-06-10 08:56:14	2021-06-10 08:56:14
19	jones	jones@123.com	\N	$2y$10$3MGoj4kicFmLTHkQahMAuOelNPGZ0O.IaybEHO9O3PGeS3RJmRzY6	123	\N	App\\Models\\Student	16	\N	2021-06-10 08:56:14	2021-06-10 08:56:14
\.


--
-- Data for Name: web_managers; Type: TABLE DATA; Schema: public; Owner: hkuit
--

COPY public.web_managers (id, created_at, updated_at) FROM stdin;
1	2021-06-10 08:56:13	2021-06-10 08:56:13
\.


--
-- Name: accounts_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_user_id_seq', 1, false);


--
-- Name: completed_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.completed_items_id_seq', 30, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.migrations_id_seq', 15, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: planned_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.planned_items_id_seq', 30, true);


--
-- Name: plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.plans_id_seq', 10, true);


--
-- Name: sports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.sports_id_seq', 4, true);


--
-- Name: statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.statistics_id_seq', 30, true);


--
-- Name: std_class_teacher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.std_class_teacher_id_seq', 8, true);


--
-- Name: std_classes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.std_classes_id_seq', 8, true);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.students_id_seq', 16, true);


--
-- Name: teachers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.teachers_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.users_id_seq', 19, true);


--
-- Name: web_managers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hkuit
--

SELECT pg_catalog.setval('public.web_managers_id_seq', 1, true);


--
-- Name: accounts accounts_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_email_key UNIQUE (email);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (user_id);


--
-- Name: accounts accounts_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_username_key UNIQUE (username);


--
-- Name: completed_items completed_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.completed_items
    ADD CONSTRAINT completed_items_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: planned_items planned_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.planned_items
    ADD CONSTRAINT planned_items_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: sports sports_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.sports
    ADD CONSTRAINT sports_pkey PRIMARY KEY (id);


--
-- Name: statistics statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.statistics
    ADD CONSTRAINT statistics_pkey PRIMARY KEY (id);


--
-- Name: std_class_teacher std_class_teacher_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.std_class_teacher
    ADD CONSTRAINT std_class_teacher_pkey PRIMARY KEY (id);


--
-- Name: std_classes std_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.std_classes
    ADD CONSTRAINT std_classes_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: students students_std_num_unique; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_std_num_unique UNIQUE (std_num);


--
-- Name: teachers teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_pkey PRIMARY KEY (id);


--
-- Name: teachers teachers_stuff_id_unique; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_stuff_id_unique UNIQUE (stuff_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: web_managers web_managers_pkey; Type: CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.web_managers
    ADD CONSTRAINT web_managers_pkey PRIMARY KEY (id);


--
-- Name: completed_items_planned_item_id_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX completed_items_planned_item_id_index ON public.completed_items USING btree (planned_item_id);


--
-- Name: completed_items_sport_id_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX completed_items_sport_id_index ON public.completed_items USING btree (sport_id);


--
-- Name: completed_items_student_id_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX completed_items_student_id_index ON public.completed_items USING btree (student_id);


--
-- Name: password_resets_email_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX password_resets_email_index ON public.password_resets USING btree (email);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: planned_items_plan_id_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX planned_items_plan_id_index ON public.planned_items USING btree (plan_id);


--
-- Name: planned_items_sport_id_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX planned_items_sport_id_index ON public.planned_items USING btree (sport_id);


--
-- Name: plans_std_class_id_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX plans_std_class_id_index ON public.plans USING btree (std_class_id);


--
-- Name: statistics_completed_item_id_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX statistics_completed_item_id_index ON public.statistics USING btree (completed_item_id);


--
-- Name: students_std_class_id_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX students_std_class_id_index ON public.students USING btree (std_class_id);


--
-- Name: users_userable_type_userable_id_index; Type: INDEX; Schema: public; Owner: hkuit
--

CREATE INDEX users_userable_type_userable_id_index ON public.users USING btree (userable_type, userable_id);


--
-- Name: std_class_teacher std_class_teacher_std_class_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.std_class_teacher
    ADD CONSTRAINT std_class_teacher_std_class_id_foreign FOREIGN KEY (std_class_id) REFERENCES public.std_classes(id);


--
-- Name: std_class_teacher std_class_teacher_teacher_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: hkuit
--

ALTER TABLE ONLY public.std_class_teacher
    ADD CONSTRAINT std_class_teacher_teacher_id_foreign FOREIGN KEY (teacher_id) REFERENCES public.teachers(id);


--
-- PostgreSQL database dump complete
--

